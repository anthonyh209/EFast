﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataDocumentDB.Models
{
    public class Child
    {
        public string FirstName { get; set; }
        public string Gender { get; set; }
        public int Grade { get; set; }
    }
}
